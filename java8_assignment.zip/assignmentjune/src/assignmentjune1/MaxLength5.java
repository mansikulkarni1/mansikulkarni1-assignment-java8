package assignmentjune1;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MaxLength5 {

		public static void main(String[] args) {



		List<String> employee = Arrays.asList("anuradha", "madhuri", "makarand", "mansi", "arundhati","swapnaja");
		Comparator<String> compByLength = (aName, bName) -> aName.length() - bName.length();
		employee.stream()
		.max(compByLength)
		.ifPresent(
		longest -> System.out.println("\nThe longest name is " + longest));
		}
		
}

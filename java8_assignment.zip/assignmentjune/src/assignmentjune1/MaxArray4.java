package assignmentjune1;

import java.util.Arrays;
import java.util.List;

public class MaxArray4 {
	public static void main(String[] args) {
		List<Integer> intList = Arrays.asList(1,2,2,3,1,5);
		int av = (int) intList.stream().mapToInt(val -> val).max().getAsInt();
		System.out.println("Maximum number found to be:"+av);
		}
		
}

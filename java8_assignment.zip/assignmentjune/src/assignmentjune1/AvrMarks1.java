package assignmentjune1;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class AvrMarks1 {

	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
             int n1=0;
             int n2=0;
             int n3=0;
             int n4=0;
             int n5=0;

             while(n1 == 0) {
            	 System.out.print("Enter Science number: ");
            	 int tempn1 = in.nextInt();
            	 if(tempn1 > 101) {	
            		 System.out.println("check number");
            	 }
            	 else {
            		 n1= tempn1;
            	 }
             }

             	while(n2 == 0) {
             		System.out.print("Enter English number: ");
             		int tempn2 = in.nextInt();
             		if(tempn2 > 101) {
             			System.out.println("check number");
             		}
             		else {
             			n2= tempn2;
             		}
             	}

             	while(n3 == 0) {
             			System.out.print("Enter Geography number: ");
             			int tempn3 = in.nextInt();
             			if(tempn3 > 101) {
             				System.out.println("check number");
             			}
             			else {
             				n3= tempn3;
             			}
             	}

             		while(n4 == 0) {
             			System.out.print("Enter Math number: ");
             			int tempn4 = in.nextInt();
             			if(tempn4 > 101) {
             			System.out.println("check number");
             			}
             			else {
             			n4= tempn4;
             			}
             		}

             		while(n5 == 0) {
             			System.out.print("Enter History number: ");
             			int tempn5 = in.nextInt();
             			if(tempn5 > 101) {
             				System.out.println("Enter number");
             			}
             			else {	
             				n5= tempn5;
	}
             		}

             	System.out.println("Average of five numbers is: " +
             	(n1 + n2 + n3 + n4 + n5) / 5);

             	List<Integer> Marks = Arrays.asList(n1 , n2 , n3 , n4 , n5);
				Double y= Marks.stream().mapToInt(val -> val).average().getAsDouble();
				System.out.println("Average of all MARKS numbers : " + y);



}

}
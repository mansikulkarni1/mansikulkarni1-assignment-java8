package assignmentjune1;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class EmpUnique3 {

	public static void main(String[] args) {


		Collection <String> employee= Arrays.asList("ekta", "manisha", "mansi", "siyona", "ekta", "manisha" );

		List<String> distinctElements = employee.stream()
		.distinct()
		.collect( Collectors.toList() );
		System.out.println( distinctElements );

		}
		
}

package assignmentjune1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AverageP6{

		public static void main(String[] args) {

		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(23);
		al.add(56);
		al.add(98);
		al.add(87);
		al.add(34);



		Double avgmark = al.stream().mapToDouble(s -> s.intValue()).average().getAsDouble();
		System.out.println("Average of marks : " +avgmark);

		List<Integer> lta=al.stream().filter(i -> i<avgmark).collect(Collectors.toList());

		System.out.println("List of numbers less than average : " +lta);

		}
		
}

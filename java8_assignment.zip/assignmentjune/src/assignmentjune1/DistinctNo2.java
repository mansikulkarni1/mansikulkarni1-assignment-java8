package assignmentjune1;

public class DistinctNo2 {

	
		static void printDistinct(int arr[], int n)
		{
		for (int i = 0; i < n; i++)
		{
		int j;
		for (j = 0; j < i; j++)
		if (arr[i] == arr[j])
		break;

		if (i == j)
		System.out.print( arr[i] + " ");
		}
		}

		public static void main (String[] args)
		{
		int arr[] = {40, 1, 25, 11, 9, 120, 11, 40, 1};
		int n = arr.length;
        printDistinct(arr,n);
		}
		
}

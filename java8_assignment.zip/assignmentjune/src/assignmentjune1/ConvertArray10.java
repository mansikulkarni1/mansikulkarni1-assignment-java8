package assignmentjune1;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class ConvertArray10 {


	String name;
	int id;
	public ConvertArray10(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	
	
	 }
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public int getId() {
	return id;
	}
	public void setId(int id) {
	this.id = id;
	}
	
	
	
	
	public static void main(String[] args) {
	ArrayList<ConvertArray10> I=new ArrayList<ConvertArray10>();
	I.add(new ConvertArray10("manju",1));
	I.add(new ConvertArray10("sanju",2));
	I.add(new ConvertArray10("ganesh",3));
	I.add(new ConvertArray10("raju",4));
	I.add(new ConvertArray10("paresh",5));
	I.add(new ConvertArray10("sanjay",6));
	I.add(new ConvertArray10("pranali",7));
	I.add(new ConvertArray10("mangesh",8));
	I.add(new ConvertArray10("sunil",9));
	I.add(new ConvertArray10("anil",10));



	 Map<Integer,String> empMap=I.stream().collect(Collectors.toMap(e->e.getId(),e->e.getName()));
	System.out.println(empMap);

	 Set<String> nameSet = I.stream().map(e->e.name).collect(Collectors.toSet());

	 System.out.println(nameSet);
	}

	}



